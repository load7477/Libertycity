vRP = Proxy.getInterface("vRP")
NewbieAuthC = {}
Tunnel.bindInterface(GetCurrentResourceName(), NewbieAuthC)
Proxy.addInterface(GetCurrentResourceName(), NewbieAuthC)
NewbieAuthS = Tunnel.getInterface(GetCurrentResourceName(), GetCurrentResourceName())
