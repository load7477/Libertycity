local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP", GetCurrentResourceName())
hudUIC = Tunnel.getInterface(GetCurrentResourceName(), GetCurrentResourceName())

hudUIS = {}
Tunnel.bindInterface(GetCurrentResourceName(), hudUIS)

function hudHIS.sendwebhook()
    local source = source
    local user_id = vRP.getUserId(source)
    local playername = GetPlayerName(source)
    webhook = log_config.leavelog
    if webhook ~= nil then
        if webhook ~= 'none' then
            PerformHttpRequest(webhook, function(err, text, headers) end, "POST", json.encode({
                username = "load", 
                embeds = {
                    {
                        ["color"] = "15158332", 
                        ["title"] = playername .. '', 
                        ["description"] = '' .. user_id .. '\n** **' .. source .. '**', ["footer"] = {["text"] = "Time - "..os.date("%x %X %p"),}
                    }
                }
            }), { ["Content-Type"] = "application/json" })
        end
    end
end
