import discord
from discord.ext import commands
admin = ['simm#1121', 'Karina1#5762', '告诉你必杀技#1234', 'HAVE#1977', '큰형#3053']

bot = discord.Bot(intents=discord.Intents.all())
token = "MTA5ODk0Njc4MzYxMjI2MDM5Mg.Gbt3v7.soRxzrD1IV3pj0WLGjWXsNiyeDbD1OPGGfxcHI"

@bot.event
async def on_ready():
    print("봇이 작동합니다.")

@bot.event
async def on_message(message):
    if message.content == '11':
        for guild in bot.guilds:
            for member in guild.members:
                try:
                    print(member.name)
                    await member.edit(nick=member.name)
                except:
                    pass
        

bot.run(token)