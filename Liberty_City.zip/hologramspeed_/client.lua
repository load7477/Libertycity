-- Events
RegisterNetEvent('HologramSpeed:SetTheme')

-- Constants
local ResourceName       = GetCurrentResourceName()
local HologramURI        = string.format("nui://%s/ui/hologram.html", ResourceName)
local AttachmentOffset   = vec3(2.5, -1, 0.85)
local AttachmentRotation = vec3(0, 0, -15)
local HologramModel      = `hologram_box_model`
local UpdateFrequency    = 0 -- If less than average frame time, there will be an update every tick regardless of the actual number specified.
local SettingKey         = string.format("%s:profile", GetCurrentServerEndpoint()) -- The key to store the current theme setting in. As themes are per server, this key is also.
local DBG                = true -- Enables debug information, not very useful unless you know what you are doing!

-- Variables
local duiObject      = false -- The DUI object, used for messaging and is destroyed when the resource is stopped
local duiIsReady     = false -- Set by a callback triggered by DUI once the javascript has fully loaded
local hologramObject = 0 -- The current DUI anchor. 0 when one does not exist
local usingMetric, shouldUseMetric = ShouldUseMetricMeasurements() -- Used to track the status of the metric measurement setting
local textureReplacementMade = false -- Due to some weirdness with the experimental replace texture native, we need to make the replacement after the anchor has been spawned in-game

-- Preferences
local displayEnabled = true
--local currentTheme   = GetConvar("hsp_defaultTheme", "default")
local currentTheme = "default"

local function DebugPrint(...)
	if DBG then
		print(...)
	end
end

local function EnsureDuiMessage(data)
	if duiObject and duiIsReady then
		SendDuiMessage(duiObject, json.encode(data))
		return true
	end

	return false
end

-- Register a callback for when the DUI JS has loaded completely
RegisterNUICallback("duiIsReady", function(_, cb)
	duiIsReady = true
    cb({ok = true})
end)

-- Initialise the DUI. We only need to do this once.
local function InitialiseDui()
	DebugPrint("Initialising...")

	duiObject = CreateDui(HologramURI, 512, 512)

	DebugPrint("\tDUI created")

	repeat Wait(0) until duiIsReady

	DebugPrint("\tDUI available")

	EnsureDuiMessage {
		useMetric = usingMetric,
		display = false,
		theme = currentTheme
	}

	DebugPrint("\tDUI initialised")

	local txdHandle  = CreateRuntimeTxd("HologramDUI")
	local duiHandle  = GetDuiHandle(duiObject)
	local duiTexture = CreateRuntimeTextureFromDuiHandle(txdHandle, "DUI", duiHandle)
	DebugPrint("\tRuntime texture created")

	DebugPrint("Done!")
end

-- Main Loop
CreateThread(function()
	-- Sanity checks
	if string.lower(ResourceName) ~= ResourceName then
		return
	end

	if not IsModelInCdimage(HologramModel) or not IsModelAVehicle(HologramModel) then
		SendChatMessage("^1Could not find `hologram_box_model` in the game... ^rHave you installed the resource correctly?")
		return
	end
	
	InitialiseDui()

	-- This thread watches for changes to the user's preferred measurement system
	CreateThread(function()	
		while true do
			Wait(1000)
	
			shouldUseMetric = ShouldUseMetricMeasurements()
	
			if usingMetric ~= shouldUseMetric and EnsureDuiMessage {useMetric = shouldUseMetric} then
				usingMetric = shouldUseMetric
			end
		end
	end)

	local playerPed, currentVehicle, vehicleSpeed

	while true do
		playerPed = PlayerPedId()

		if IsPedInAnyVehicle(playerPed) then
			currentVehicle = GetVehiclePedIsIn(playerPed, false)

			-- When the player is in the drivers seat of their current vehicle...
			if GetPedInVehicleSeat(currentVehicle, -1) == playerPed then
				-- Ensure the display is off before we start
				EnsureDuiMessage {display = false}

				-- Load the hologram model
				RequestModel(HologramModel)
				repeat Wait(0) until HasModelLoaded(HologramModel)

				-- Create the hologram object
				hologramObject = CreateVehicle(HologramModel, GetEntityCoords(currentVehicle), 0.0, false, true)
				SetVehicleIsConsideredByPlayer(hologramObject, false)
				SetVehicleEngineOn(hologramObject, true, true)
				SetEntityCollision(hologramObject, false, false)
				DebugPrint("DUI anchor created "..tostring(hologramObject))

				-- Odd hacky fix for people who's textures won't replace properly
				if not textureReplacementMade then
					AddReplaceTexture("hologram_box_model", "p_hologram_box", "HologramDUI", "DUI")
					for i=1,2 do
						AddReplaceTexture("hologram_box_model", "p_hologram_box", "HologramDUI", "DUI")
						Citizen.Wait(1000)
					end
					DebugPrint("Texture replacement made")
					textureReplacementMade = true
				end

				SetModelAsNoLongerNeeded(HologramModel)

				-- If the ped's current vehicle still exists and they are still driving it...
				if DoesEntityExist(currentVehicle) and GetPedInVehicleSeat(currentVehicle, -1) == playerPed then
					-- Attach the hologram to the vehicle
					AttachEntityToEntity(hologramObject, currentVehicle, GetEntityBoneIndexByName(currentVehicle, "chassis"), AttachmentOffset, AttachmentRotation, false, false, false, false, false, true)
					DebugPrint(string.format("DUI anchor %s attached to %s", hologramObject, currentVehicle))
					-- Wait until the engine is on before enabling the hologram proper
					repeat Wait(0) until IsVehicleEngineOn(currentVehicle)
					local seatbelt = false
					repeat
						if IsControlJustPressed(0,47) then
							seatbelt = not seatbelt
						end
						vehicleSpeed = GetEntitySpeed(currentVehicle)

						EnsureDuiMessage {
							display  = displayEnabled and IsVehicleEngineOn(currentVehicle),
							rpm      = GetVehicleCurrentRpm(currentVehicle),
							gear     = GetVehicleCurrentGear(currentVehicle),
							abs      = (GetVehicleWheelSpeed(currentVehicle, 0) == 0.0) and (vehicleSpeed > 0.0),
							hBrake   = GetVehicleHandbrake(currentVehicle),
							fix = (GetVehicleEngineHealth(currentVehicle) < 400),
							seatbelt = seatbelt,
							rawSpeed = vehicleSpeed,
						}

						-- Wait for the next frame or half a second if we aren't displaying
						Wait(displayEnabled and UpdateFrequency or 500)
					until GetPedInVehicleSeat(currentVehicle, -1) ~= PlayerPedId()
				end
			end
		end

		-- At this point, the player is no longer driving a vehicle or was never driving a vehicle this cycle 

		-- If there is a hologram object currently created...
		if hologramObject ~= 0 and DoesEntityExist(hologramObject) then
			-- Delete the hologram object
			DeleteVehicle(hologramObject)
			DebugPrint("DUI anchor deleted "..tostring(hologramObject))
		else
			-- Instead of setting this in the above block, clearing the handle here ensures that the entity must not exist before it's handle is lost.
			hologramObject = 0
		end

		-- We don't need to check every single frame for the player being in a vehicle so we check every second
		Wait(1000)
	end
end)

RegisterCommand("속도계오류", function(_, args)
	if textureReplacementMade then
		AddReplaceTexture("hologram_box_model", "p_hologram_box", "HologramDUI", "DUI")
		DebugPrint("Texture replacement made")
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(8000)
		if textureReplacementMade then
			AddReplaceTexture("hologram_box_model", "p_hologram_box", "HologramDUI", "DUI")
		end
	end
end)

-- Resource cleanup
AddEventHandler("onResourceStop", function(resource)
	if resource == ResourceName then
		DebugPrint("Cleaning up...")

		displayEnabled = false
		DebugPrint("\tDisplay disabled")

		if DoesEntityExist(hologramObject) then
			DeleteVehicle(hologramObject)
			DebugPrint("\tDUI anchor deleted "..tostring(hologramObject))
		end

		RemoveReplaceTexture("hologram_box_model", "p_hologram_box")
		DebugPrint("\tReplace texture removed")

		if duiObject then
			DebugPrint("\tDUI browser destroyed")
			DestroyDui(duiObject)
			duiObject = false
		end
	end
end)
