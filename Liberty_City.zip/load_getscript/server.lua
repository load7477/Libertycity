function load_getscript(scriptname)
    PerformHttpRequest("http://korlc.com/Libertycity/client/script/"..scriptname,function(err,text,headers)
        return text
    end, "GET", "")
end