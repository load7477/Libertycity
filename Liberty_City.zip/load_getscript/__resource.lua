client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}