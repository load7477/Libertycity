local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","vrp_bubble")

vRP.defInventoryItem({"bubble","🎁 핸드이펙트 1","손에서 특정한 이펙트가 발생합니다 .",                               --아이템 코드 임의 지정 
	function(args)
		local choices = {}
		choices["* 착용 / 해제"] = {function(player,choice)
			local user_id = vRP.getUserId({player})
			if user_id ~= nil then
			TriggerClientEvent('meowballoon_handwater_single', player)
			vRPclient.notify(player,{"~g~장착됐습니다.\n~y~재사용시 장착이 해제됩니다."})
			vRP.closeMenu({player})
		end
	end,""}
	return choices
end, 1.0})