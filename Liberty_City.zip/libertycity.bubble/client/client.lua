--구문이해를 돕기위해 컨버팅합니다. 컨버팅 별거없습니다. 공부하면서 하다보면 구문이 조금찍 보일겁니다 하지만 양심도양심이지만 팔지 맙시다.

RegisterNetEvent('meowballoon_handwater_single')
AddEventHandler('meowballoon_handwater_single', function ()
	--v = Config.bayusecloth.zone02 --config.lua 를 삭제하여 제거합니다.
	
	if not wheel then 
	wheel = true 
	local ped = GetPlayerPed(-1) 
	local position = GetEntityCoords(GetPlayerPed(PlayerId()), false) 
	local object = GetClosestObjectOfType(position.x, position.y, position.z, 15.0, GetHashKey("meowballoon_handwater_single"), false, false, false) --	v.objectprop 를 오브젝트로 모델명으로 변경 config 참고
	--[[if v.printdebug then print("USE PROP |"..v.objectprop) 
	end]]-- 필요없음
	if object ~= 0 then 
	DeleteObject(object) 
	end 
	local x,y,z = table.unpack(GetEntityCoords(ped)) 
	local prop = CreateObject(GetHashKey("meowballoon_handwater_single"), x, y, z + 0.2, true, true, true)  --	v.objectprop 를 오브젝트로 모델명으로 변경 config 참고
	local boneIndex = GetPedBoneIndex(ped, 0x6f06) --config에 있는  boneIndex1를 그대로 넣어줌 
	AttachEntityToEntity(prop, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 90.0, 0.0, true, true, false, true, 1, true) --config에 있는  location1를 그대로 넣어줌
	else 
	
	local ped = GetPlayerPed(-1) 
	local position = GetEntityCoords(GetPlayerPed(PlayerId()), false) 
	local object2 = GetClosestObjectOfType(position.x, position.y, position.z, 15.0, GetHashKey("meowballoon_handwater_single"), false, false, false) --	v.objectprop 를 오브젝트로 모델명으로 변경 config 참고
	if object2 ~= 0 then 
	DeleteObject(object2) 
	end 
	
	local x,y,z = table.unpack(GetEntityCoords(ped)) 
	local prop2 = CreateObject(GetHashKey("meowballoon_handwater_single"), x, y, z + 0.2, true, true, true) --	v.objectprop 를 오브젝트로 모델명으로 변경 config 참고
	local boneIndex = GetPedBoneIndex(ped, 0x6f06) --config에 있는  boneIndex2를 그대로 넣어줌 
	AttachEntityToEntity(prop2, ped, boneIndex, 0.0, 0.0, 0.0, 0.0, 90.0, 0.0, true, true, false, true, 1, true) --config에 있는  location1를 그대로 넣어줌
	ClearPedTasks(ped) 
	wheel = false 
	DetachEntity(prop2, ped, boneIndex,0.0, 0.0, 0.0, 0.0, 90.0, 0.0, true, true, false, true, 1, true) --config에 있는  location1를 그대로 넣어줌
	DeleteObject(prop2)
	end
end)

