fx_version 'adamant'
game 'gta5'

description 'ResetShop'

version '1.2.0'

client_scripts {
  --"config.lua", config 제거
  "client/client.lua"
}

server_scripts {
  "@vrp/lib/utils.lua",
  --"config.lua", config 제거
  "server/server.lua"
}

files {   
  "stream/meowballoon_handwater_single.ydr"
}	

data_file "DLC_ITYP_REQUEST" "stream/meowballoon_handwater_single.ytyp"