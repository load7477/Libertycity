import os
import subprocess
import time

def main():
    if not os.name == "nt":
        print("This program only works on Windows.")
        time.sleep(3)
        exit()
    hwid = str(subprocess.check_output('wmic csproduct get uuid')).split('\\r\\n')[1].strip('\\r').strip()
    print(f"{hwid}.")
    print("복사 완료")
    os.system('echo ' + hwid + '| clip')
    print(' ')
    os.system("pause")

if __name__ == "__main__":
    main()