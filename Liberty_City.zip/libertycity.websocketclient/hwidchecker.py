import configparser
import sys
import os
import subprocess
import time
import webbrowser
from windows_toasts import WindowsToaster, ToastText1
wintoaster = WindowsToaster('Libert City')
newToast = ToastText1()


if sys.argv[1] == '08212013-6C58-0D25-7CD5-586C250D7CD9':
    newToast.SetBody('서버에 접속중입니다 ..')
    newToast.on_activated = lambda _: print('')
    wintoaster.show_toast(newToast)
    webbrowser.open('fivem://localhot:30120') # Go to example.com
else:
    newToast.SetBody('서버 접속을 실패 하엿습니다')
    newToast.on_activated = lambda _: print('')
    wintoaster.show_toast(newToast)