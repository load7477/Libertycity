-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        10.4.27-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- libertycity 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `libertycity` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `libertycity`;

-- 테이블 libertycity.account 구조 내보내기
CREATE TABLE IF NOT EXISTS `account` (
  `connect` varchar(50) DEFAULT NULL,
  `ids` varchar(50) DEFAULT NULL,
  `pw` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 libertycity.account:~1 rows (대략적) 내보내기
INSERT IGNORE INTO `account` (`connect`, `ids`, `pw`) VALUES
	('2023/04/10 20:19', 'load', '11');

-- 테이블 libertycity.notice 구조 내보내기
CREATE TABLE IF NOT EXISTS `notice` (
  `idx` int(11) DEFAULT NULL,
  `noticetitle` varchar(50) DEFAULT NULL,
  `noticetype` varchar(50) DEFAULT NULL,
  `message` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `usertype` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 테이블 데이터 libertycity.notice:~2 rows (대략적) 내보내기
INSERT IGNORE INTO `notice` (`idx`, `noticetitle`, `noticetype`, `message`, `title`, `time`, `usertype`, `name`) VALUES
	(1, '2023-04-08 Event', 'Event', '테스트', 'Test', '2023-04-08', 'Dev', 'load'),
	(2, '2023-04-06 Event', 'Patch', '테스트', 'Test', '2023-04-06', 'Dev', 'load');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
