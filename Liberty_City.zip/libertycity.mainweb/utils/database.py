import pymysql, string, random
from flask import Flask,render_template, request, session, redirect, flash

def pick(_LENGTH):
    string_pool = string.ascii_letters + string.digits
    result = "" 
    for i in range(_LENGTH) :
        result += random.choice(string_pool)
    return result

print(pick(50))

def getnotice():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='libertycity', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM notice")
    return cur.fetchall()

def GetNoticeType(ID):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='libertycity', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM notice WHERE noticetype='"+str(ID)+"';")
    return cur.fetchall()


def GetNewsID(ID):
    try:
        con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='libertycity', charset='utf8')
        cur = con.cursor(pymysql.cursors.DictCursor)
        cur.execute(f"SELECT * FROM notice WHERE idx='"+str(ID)+"';")
        return cur.fetchone()
    except:
        pass