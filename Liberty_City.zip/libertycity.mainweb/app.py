from flask import Flask, render_template, session
import route_function
import pymysql
from datetime import timedelta
import time
now = time.strftime("%Y-%m-%d", time.gmtime())

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

app.add_url_rule("/","index",route_function.main) # main site
app.add_url_rule("/Perm","Perm",route_function.Perm) # Perm Main
app.add_url_rule("/Support/<type>","Support",route_function.support) # Support
app.add_url_rule("/News/<type>","News",route_function.News) # News
app.add_url_rule("/News/idx=<type>","Newsview",route_function.Newsview) # News
app.add_url_rule("/User/Login","userlogin",route_function.login) # User Login
app.add_url_rule("/User/Logout","logout",route_function.logout) # User Logout
app.add_url_rule("/contact", "contact",route_function.contact) # User contact
app.add_url_rule("/discord", "discord",route_function.discord) # User contact
app.add_url_rule("/login_check", "login_check",route_function.api_login, methods = ['POST', 'GET']) # User Login CHeck
app.add_url_rule("/check/<type>", "check",route_function.checks, methods = ['POST', 'GET']) # User Login CHeck

@app.errorhandler(404)
def not_found(e):
    return render_template("error/404.html")

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=60)

if __name__ == '__main__':
    app.run(host="0.0.0.0",port=80)