from flask import Flask,render_template, request, session, redirect, flash, url_for
import pymysql
import utils.database as db
import time, requests, json
import string
import random

# <!-- main route -->
app = Flask(__name__)


def main():
    if '156.96.155.23' != request.remote_addr :
        nts = db.getnotice()
        return render_template('index.html')
    else:
        return '꺼져 병신아'

def Perm():
    if '156.96.155.23' != request.remote_addr :
        nts = db.getnotice()
        if 'username' in session:
            result = ["none", "block"]
        else:
            result = ["block", "none"]
        return render_template('Perm.html', nts = nts, html=result)
    else:
        return '꺼져 병신아'
    
def News(type):
    display = [{}]
    if type == 'All':
        a = 'All'
        s = db.getnotice()
        return render_template("news/news.html", s=s, type=type)
    elif type == 'Notice':
        a = 'Notice'
    elif type == 'Event':
        a = 'Event'
    elif type == 'PatchNotes':
        a = 'Patch'
    elif type == 'Maintainance':
        a = 'Maintainance'
    s = db.GetNoticeType(a)
    return render_template("news/news.html", s=s, type=type)

def Newsview(type):
    a = db.GetNewsID(type)
    message = a['message'].replace("\n", "<br>")
    return render_template("news/view.html", view=a, message=message)

def contact(type):
    a = db.GetNewsID(type)
    message = a['message'].replace("\n", "<br>")
    return render_template("news/view.html", view=a, message=message)


def support(type):
    if type == '01':
        return render_template("support/01.html")
    elif type == '02':
        return render_template("support/02.html")
    elif type == '03':
        return render_template("support/03.html")
    elif type == '04':
        return render_template("support/04.html")
    return render_template("error.html")

def logins(id, pw):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='libertycity', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM account WHERE ids='"+str(id)+"';")
    rows = cur.fetchone()
    cur.execute(f"UPDATE account SET connect='{time.strftime('%Y/%m/%d %H:%M')}' WHERE ids='{str(id)}';")
    con.commit()
    con.close()
    if rows != None:
        if rows["pw"] == pw:
            return True 
        else:
            return False 
    else:
        return False

def api_login():
    username = request.form['username']
    password = request.form['password']
    if username in "'" or username in '"' or username in "<" or username in ">" or password in "'" or password in '"' or password in "<" or password in ">":
        pass
    login = logins(username, password)
    if login == False:
        return redirect('/User/Login')
    else:
        if login == True:
            session["username"] = username
            return redirect(f'/')
        
def login():
    if '156.96.155.23' != request.remote_addr :
        return render_template('login.html')
    else:
        return '꺼져 병신아'

def logout():
    session.pop('username', None)
    return redirect('/Perm')

def checks(type):
    if type == "a5gyyxvmZFKgcX5fbZTMJA777oS1TCY3Q19BSfAgxC0ML7CrRb":
        return redirect("/discord")     
    elif type == "dMWMtuHq4HaTCnwPsLDvfRV1n0ynTCikZmZYzSTX7LbGQ9OHIa":
        return redirect("/download")
    else: return "ERROR"

def discord():
    return redirect("http://discord.gg/krlc")
