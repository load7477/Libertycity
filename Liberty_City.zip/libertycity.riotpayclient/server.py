from flask import Flask, render_template
app = Flask(__name__)

# 일반적인 라우트 방식입니다.
@app.route('/')
def board():
    return render_template("index.html")

app.run(host="0.0.0.0",port=5001)