$(function() {	
	var $box = $(".box");
	var $box1 = $(".box1");
	var $box2 = $(".box2");

	window.addEventListener('message', function(event){
        $box.css("width", (event.data.health)+"%");
        $box1.css("width", (event.data.armor)+"%");
        $box2.css("width", (event.data.armor)+"%");
        if (event.data.type == 'close') {
            if (document.querySelector('.user_hpinfo').style.display == 'block') {
                document.querySelector('.user_hpinfo').style.display = 'none';
                document.querySelector('.user_computerinfo').style.display = 'none';
            } else {
                document.querySelector('.user_hpinfo').style.display = 'block';
                document.querySelector('.user_computerinfo').style.display = 'block';
            }
        }
	}); 
});
