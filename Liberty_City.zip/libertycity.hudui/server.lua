local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP", GetCurrentResourceName())
hudUIC = Tunnel.getInterface(GetCurrentResourceName(), GetCurrentResourceName())

hudUIS = {}
Tunnel.bindInterface(GetCurrentResourceName(), hudUIS)

function hudUIS.GetInfo()
	local userID = vRP.getUserId({source})
    local src = source
    local CurrentPing = GetPlayerPing(src)
    local mp = vRP.getHunger({userID})*vRP.getThirst({userID}) 
end
