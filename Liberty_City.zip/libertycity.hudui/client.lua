vRP = Proxy.getInterface("vRP")
hudUIC = {}
Tunnel.bindInterface(GetCurrentResourceName(), hudUIC)
Proxy.addInterface(GetCurrentResourceName(), hudUIC)
hudUIS = Tunnel.getInterface(GetCurrentResourceName(), GetCurrentResourceName())


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(100)
        hudUIC.SendNui() 
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustReleased(0--[[control type]],  51--[[control index]]) then
            SendNUIMessage(
                {
                    type = "close"
                }
            )
        end
    end
end)

function hudUIC.PingC(ping)
    SendNUIMessage(
        {
            ping = ping
        }
    )
end

function hudUIC.SendNui() 
    local playerId = PlayerId()
    local ped = GetPlayerPed(-1)
    local armor = GetPedArmour(ped)
    local mp = hudUIS.GetInfo({source})
    SendNUIMessage(
        {
            armor = armor,
            health = (GetEntityHealth(GetPlayerPed(-1))-100),
        }
    )
end